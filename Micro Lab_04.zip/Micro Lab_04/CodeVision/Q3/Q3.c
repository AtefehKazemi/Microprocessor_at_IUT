#include <header.h>

// Declare your global variables here

void main(void)
{
// Declare your local variables here

      init();
      Wave();

while (1)
      {
      // Place your code here

      }
}
