#ifndef __funcs_INCLUDE__
#define __funcs_INCLUDE__

void Wave();
void init();

#endif