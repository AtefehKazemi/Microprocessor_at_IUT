#include <mega16.h>
#include <alcd.h>
#include <funcs.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>