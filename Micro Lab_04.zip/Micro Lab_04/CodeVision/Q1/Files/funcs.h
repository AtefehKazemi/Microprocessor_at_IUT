#ifndef __funcs_INCLUDE__
#define __funcs_INCLIUDE__

void timer_init();
void init();
interrupt [EXT_INT1] void ext_int1_isr(void);
interrupt [TIM0_OVF] void timer0_ovf_isr(void);

#endif