#include <header.h>

// Global Variable
char ms = 0;
char sec = 0;
char min = 0;
char hour = 0;
char flag = 0;

unsigned char* ms_str = "00";
unsigned char* sec_str = "00";
unsigned char* min_str = "00";
unsigned char* hour_str = "00";

void main(void)
{
    // Declare your local variables here
    init();

           
    // Global enable interrupts
    #asm("sei")
    DDRB = 0x00;
    
    while (1)
      {
      // Place your code here

      }
}

