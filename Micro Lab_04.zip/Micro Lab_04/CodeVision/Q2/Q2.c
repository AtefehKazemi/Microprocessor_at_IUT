#include <header.h>

// Declare your global variables here

int capacity = 1000;
// External Interrupt 0 service routine

void main(void)
{
// Declare your local variables here


// Global enable interrupts
    init();
    DDRB = 0x00;
    #asm("sei")

while (1)
      {
      // Place your code here

      }
}
