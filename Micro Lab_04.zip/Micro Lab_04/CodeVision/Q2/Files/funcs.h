#ifndef __funcs_INCLUDE__
#define __funcs_INCLIUDE__

void init();
interrupt [EXT_INT0] void ext_int0_isr(void);

#endif