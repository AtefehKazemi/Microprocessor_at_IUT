#ifndef __functions_INCLUDE__
#define __functions_INCLUDE__

void routin1(int BAUD, int transmitter_status, int reciever_status);
void Q2(void);
void Q3(void);

#endif