#ifndef __init_INCLUDE__
#define __init_INCLUDE__

void init(void);

#endif