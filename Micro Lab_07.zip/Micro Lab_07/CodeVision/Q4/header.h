#ifndef __header_INCLUDE__
#define __header_INCLUDE__

#include <mega16.h>
#include <alcd.h>
#include <stdio.h>
#include <init.h>
#include <functions.h>
char getchar_(void);
void putchar_(char c);

#endif