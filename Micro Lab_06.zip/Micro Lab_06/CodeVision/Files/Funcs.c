#include <header.h>


// Read the AD conversion result
unsigned int read_adc(unsigned char adc_input)
{
    ADMUX=adc_input | ADC_VREF_TYPE;
    // Delay needed for the stabilization of the ADC input voltage
    delay_us(10);
    // Start the AD conversion
    ADCSRA|=(1<<ADSC);
    // Wait for the AD conversion to complete
    while ((ADCSRA & (1<<ADIF))==0);
    ADCSRA|=(1<<ADIF);
    return ADCW;
}

void Q1(){
    i = 0;
    result = 0;
    temp1 = 0;
    temp2 = 0;

    timerInitQ1Q2();
    interruptInit();
    ADCinitQ1Q3();

    lcd_clear();
    lcd_gotoxy(0,0);
    lcd_puts("Q1:");

    for(i = 0; i < 8; i++){
        result = read_adc(i);
        temp2 = result * 5;
        temp1 = temp2 / 1023;
        temp1 = temp1 * 1000;
        result = floor(temp1); 
        sprintf(resultStr,"ADC(%d): %d mv",i,result);
        lcd_gotoxy(0,1);
        lcd_puts("                ");
        lcd_gotoxy(0,1);
        lcd_puts(resultStr);
        delay_ms(1000);
    }
}

void Q2(){


    timerInitQ1Q2();
    interruptInit();
    ADCinitQ2();
       i = -1;
}

void Q3(){
    timerInitQ3();
    interruptInit();
    ADCinitQ1Q3();
    #asm("sei")


}

void Q4(){
    Q1();
    lcd_clear();
    lcd_gotoxy(0,0);

    lcd_puts("Q3 for 15 sec");
    Q3();
    delay_ms(15000);

    Q2(); 


}
