#ifndef _functions_INCLUDED_
#define _functions_INCLUDED_

void ioInit();

void interruptInit();

void timerInitQ1Q2();
void timerInitQ3();


void ADCinitQ1Q3();
void ADCinitQ2();

unsigned int read_adc(unsigned char adc_input);
void Q1();
void Q2();
void Q3();
void Q4();

#endif

