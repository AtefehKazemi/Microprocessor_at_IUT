#ifndef _define_INCLUDED__
#define _define_INCLUDED__


#include <mega16.h>

// Graphic Display functions
#include <glcd.h>

// Font used for displaying text
// on the graphic display
#include <font5x7.h>
#include <math.h>

// Declare your global variables here
#include <delay.h>
#include <functions.h>
#include <image.h>



// Declare your global variables here
extern const unsigned short AK[];
//extern flash unsigned char ds[];



extern long x;
extern long y;
extern int second;
extern int minute;
extern int hour;


#endif