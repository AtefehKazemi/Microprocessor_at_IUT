#include <header.h>



void Q1(){

    int k,j;
    int r = 0;
    int c = 0;
    int max_column = 8;
    int min_column = 0; 
    int i=0;  
    while(1){
        for(i=0;i<150;i++){
                PORTD = 0x80;
                PORTB = AK[r];
                PORTA = 1<<c;

                for(k = 0; k < 100; k++)
                {   
                    for(j = 0; j < 10; j++)
                        ;
                }

                PORTD = 0x00;
                PORTB = AK[r+8];
                PORTA = 1<<c;

                r++;
                if (r == max_column)
                {
                    r = min_column;   
                }
                c = (c+1)%8;
                for(k = 0; k < 100; k++)
                {   
                    for(j = 0; j < 10; j++)
                        ;
                }
                
          } 
                 
          if (max_column == 248)
          {
            max_column = 8;
            min_column = 0;
            r=0;
            c=0;
          }
                 
          else
          { 
             max_column =  max_column + 16;
             min_column = min_column + 16;
          }

    }        

}

void Q2(){
    glcd_putimagef(0,0,new_image,GLCD_PUTCOPY);

}

void Q3(){
    
        

        second++;
        if(second == 60)
        {
            minute++;
            second = 0;  
        }
        if(minute == 60)
        {
            hour++;
            minute = 0;
        }
        if(hour == 12){
            hour = 0;  
            
        }
        
        glcd_clear();
       
        glcd_circle(63, 31, 30);
        glcd_setlinestyle(3,4);
        glcd_circle(63, 31, 2);
        glcd_setlinestyle(1,GLCD_LINE_SOLID); 

        x = 25*cos(second*6);
        y = 25*sin(second*6);
      
        glcd_line(63,31,x+63,31-y); 
        
        x = 20*cos(minute*6);
        y = 20*sin(minute*6);
        
        glcd_line(63,31,x+63,31-y); 
        
        x = 15*cos(hour*6);
        y = 15*sin(hour*6);
        
        glcd_line(63,31,x+63,31-y); 
}