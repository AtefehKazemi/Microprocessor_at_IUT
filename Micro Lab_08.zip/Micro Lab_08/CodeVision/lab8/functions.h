#ifndef _functions_INCLUDED__
#define _functions_INCLUDED__

void IO_Init();
void TimerInit();
void Q1();
void Q2();
void Q3();



#endif