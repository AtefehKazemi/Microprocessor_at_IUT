#include <mega16.h>
#include <alcd.h>
#include <delay.h>
#include <string.h>