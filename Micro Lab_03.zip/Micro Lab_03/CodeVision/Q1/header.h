#include <mega16.h>

// Alphanumeric LCD functions
#include <alcd.h>