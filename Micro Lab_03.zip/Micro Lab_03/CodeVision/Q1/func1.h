#ifndef __func1_INCLUDE__
#define __func1_INCLUDE__

void func1(void);

#endif