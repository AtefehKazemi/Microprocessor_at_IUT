#include <header.h>

void func1(void){
    lcd_init(16);
    lcd_clear();
    lcd_puts("Kazemi");
    lcd_gotoxy(0,1);
    lcd_puts("9737473");    
    return;
}