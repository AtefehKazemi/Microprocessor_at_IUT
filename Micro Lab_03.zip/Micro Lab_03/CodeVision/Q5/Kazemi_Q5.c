/*
 * Kazemi_Q5.c
 *
 * Created: 3/15/2022 9:01:38 PM
 * Author: Kazemi
 */

#include <header.h>
#include <func5.h>


void main(void){
    ioInit();
    interruptInit();
    lcd_init(16);  // Alphanumeric LCD initialization

    func5();

}
