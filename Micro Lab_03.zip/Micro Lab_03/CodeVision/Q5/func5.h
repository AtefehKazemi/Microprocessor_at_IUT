#ifndef__func5_INCLUDE__
#define__func5_INCLUDE__



void func5(void);
void keyPadFunc();
void ioInit();
void interruptInit();



#endif