#ifndef __header_INCLUDE__
#define __header_INCLUDE__


#include <mega16.h>
#include <alcd.h>
#include <delay.h>
#include <string.h>

extern unsigned char temp;
extern unsigned char KeyPad[4][4];


#endif


