#include <header.h>
#include <func6.h>




void func4(void){
            DDRB = 0xF0;
            PORTB = 0xFF;
            #asm("sei")     // Global enable interrupts

}
