#ifndef __func6_INCLUDE__
#define __func6_INCLUDE__


void func1();
void func2();
void func3();
void func4();
void func5();
void keyPadFunc();
void ioInit();
void interruptInit();


#endif
