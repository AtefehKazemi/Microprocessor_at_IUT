#include <header.h>

void func1(void){
    lcd_init(16);
    lcd_clear();
    lcd_gotoxy(0,0);
    lcd_puts("Atefeh Kazemi");
    lcd_gotoxy(0,1);
    lcd_puts("9737473");
    delay_ms(2200);    
    return;
}