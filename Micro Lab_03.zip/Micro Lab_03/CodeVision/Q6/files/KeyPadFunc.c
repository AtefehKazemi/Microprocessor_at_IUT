#include <header.h>




void keyPadFunc(){
    unsigned char row;
    unsigned char column;
    DDRB = 0xF0;
    PORTB = 0xFF;


        while(1){
            PORTB = 0b11111111;
            column = (PINB & 0b00001111);
            if (column != 0b00000000) 
                break;
        }

         while(1){
            PORTB = 0b11111111;
            column= (PINB & 0b00001111);
            if (column == 0b00000000) 
                break;
        }


        while(1){
            while (1) {
                delay_ms(25);
                column = (PINB & 0b00001111);
                if (column == 0b00000000) 
                  break;
            }

            delay_ms(25);
            column = (PINB & 0b00001111);
            if(column != 0b00000000) 
                 break;
        }

        while (1){
            PORTB = 0b00011111;
            column = (PINB & 0b00001111);

            if (column != 0b00000000)
            {
                row = 0;
                break;
            }

            PORTB = 0b00101111;
            column = (PINB & 0b00001111);

            if (column != 0b00000000)
            {
                row = 1;
                break;
            }

            PORTB = 0b01001111;
            column = (PINB & 0b00001111);

            if (column != 0b00000000)
            {
                row = 2;
                break;
            }

            PORTB = 0b10001111;
            column = (PINB & 0b00001111);

            if (column != 0b00000000)
            {
                row = 3;
                break;
            }
        }

        switch (column) {
            case 0b00000001:
                lcd_putchar(KeyPad[row][0]);
                temp = KeyPad[row][0];
                break;
            case 0b00000010:
                lcd_putchar(KeyPad[row][1]);
                temp = KeyPad[row][1];
                break;
            case 0b00000100:
                lcd_putchar(KeyPad[row][2]);
                temp = KeyPad[row][2];
                break;
            case 0b00001000:
                lcd_putchar(KeyPad[row][3]);
                temp = KeyPad[row][3];
                break;
        }


}