#include <header.h>
#include <func6.h>

void func3(void){
        unsigned int counter = 0;
        lcd_clear();
        lcd_gotoxy(0,0);
      while(1){
        if (counter == 3){  
           lcd_clear();
           lcd_gotoxy(0,0);
           break;
           }
        keyPadFunc();
        counter++;
      }
}
