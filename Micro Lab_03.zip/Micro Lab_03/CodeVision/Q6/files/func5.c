#include <header.h>
#include <func6.h>

void func5(){
        unsigned char FirstDigit;
        unsigned char SecondDigit;
        
        
        lcd_clear();
        lcd_gotoxy(0,0);
        lcd_puts("Enter number forSPEED(0-50):");
        keyPadFunc();
        FirstDigit = temp;
        keyPadFunc();
        SecondDigit = temp;
        delay_ms(50); 
        
        if(FirstDigit > '5' || SecondDigit > '9' || FirstDigit < '0' || 
                                                   (FirstDigit == '5' && SecondDigit != '0')){
            lcd_clear();
            lcd_gotoxy(0,0);
            lcd_puts("SPEED EE for ");
            lcd_putchar(FirstDigit);
            lcd_putchar(SecondDigit);
            
        }
        else {
            lcd_clear();
            lcd_gotoxy(0,0);
            lcd_puts("Set successfully");
            lcd_putchar(FirstDigit);
            lcd_putchar(SecondDigit);
           
        } 
        
        

        delay_ms(1400);
         
        
        lcd_clear();
        lcd_gotoxy(0,0);
        lcd_puts("Enter number forTIME(0-99s):");
        keyPadFunc();
        FirstDigit = temp;
        keyPadFunc();
        SecondDigit = temp;
        delay_ms(50);
        if(FirstDigit > '9' || SecondDigit > '9'){
            lcd_clear();
            lcd_gotoxy(0,0);
            lcd_puts("TIME EE for ");
            lcd_putchar(FirstDigit);
            lcd_putchar(SecondDigit);
        }
        else {
            lcd_clear();
            lcd_gotoxy(0,0);
            lcd_puts("Set successfully");
            lcd_putchar(FirstDigit);
            lcd_putchar(SecondDigit);
        }

        delay_ms(1400);

        lcd_clear();
        lcd_gotoxy(0,0);
        lcd_puts("Enter number forWEIGHT(0-99F):");
        keyPadFunc();
        FirstDigit = temp;
        keyPadFunc();
        SecondDigit = temp;
        delay_ms(50);
        if(FirstDigit > '9' || SecondDigit > '9'){
            lcd_clear();
            lcd_gotoxy(0,0);
            lcd_puts("WEIGHT EE for ");
            lcd_putchar(FirstDigit);
            lcd_putchar(SecondDigit);
        }
        else {
            lcd_clear();
            lcd_gotoxy(0,0);
            lcd_puts("Set successfully");
            lcd_putchar(FirstDigit);
            lcd_putchar(SecondDigit);
        }

        delay_ms(1400);

        lcd_clear();
        lcd_gotoxy(0,0);
        lcd_puts("Enter number forTEMP(20-80C):");
        keyPadFunc();
        FirstDigit = temp;
        keyPadFunc();
        SecondDigit = temp;
        delay_ms(50);
        if(FirstDigit > '8' || SecondDigit > '9' || FirstDigit < '2' || 
                                           (FirstDigit == '8' && SecondDigit != '0')){
            lcd_clear();
            lcd_gotoxy(0,0);
            lcd_puts("TEMP EE for ");
            lcd_putchar(FirstDigit);
            lcd_putchar(SecondDigit);
        }
        else {
            lcd_clear();
            lcd_gotoxy(0,0);
            lcd_puts("Set successfully");
            lcd_putchar(FirstDigit);
            lcd_putchar(SecondDigit);
        }

        delay_ms(1400);

}



