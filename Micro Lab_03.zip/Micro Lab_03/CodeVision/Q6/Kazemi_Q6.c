/*
 * Kazemi_Q6.c
 *
 * Created: 3/15/2022 10:51:20 PM
 * Author: Kazemi
 */

#include <header.h>
#include <func6.h>


unsigned char temp;
unsigned char KeyPad[4][4] = {
'0','1','2','3',
'4','5','6','7',
'8','9','A','B',
'C','D','E','F'
};

// External Interrupt 1 service routine
interrupt [EXT_INT1] void myInterrupt(void)
{

        DDRC = 0x01;
        PORTC = 0x01;
        DDRB = 0xF0;
        PORTB = 0xFF;
        keyPadFunc();
        DDRB = 0xF0;
        PORTB = 0xFF;
        PORTC = 0x00;

}

void main(void){
    ioInit();
    interruptInit();
    lcd_init(16);  // Alphanumeric LCD initialization
    
    func1();
    func2();
    lcd_puts("Question 3");
    delay_ms(500);
    lcd_clear();
    lcd_gotoxy(0,0);
    func3();
    func5();
    lcd_clear();
    lcd_gotoxy(0,0);
    lcd_puts("Question 4");
    delay_ms(700);
    lcd_clear();
    lcd_gotoxy(0,0);
    func4();

}
