#ifndef__func3and4_INCLUDE__
#define__func3and4_INCLUDE__



void func4(void);
void keyPadFunc();
void ioInit();
void interruptInit();







#endif