/*
 * Kazemi_Q4.c
 *
 * Created: 3/15/2022 8:40:36 PM
 * Author: Kazemi
 */
 
 
#include <header.h>
#include <func3and4.h>




// External Interrupt 1 service routine
interrupt [EXT_INT1] void myInterrupt(void)
{

        DDRC = 0x01;
        PORTC = 0x01;
        DDRB = 0xF0;
        PORTB = 0xFF;
        keyPadFunc();
        DDRB = 0xF0;
        PORTB = 0xFF;
        PORTC = 0x00;

}


void main(void){
    ioInit();
    interruptInit();
    lcd_init(16);  // Alphanumeric LCD initialization
    func4();
    }

