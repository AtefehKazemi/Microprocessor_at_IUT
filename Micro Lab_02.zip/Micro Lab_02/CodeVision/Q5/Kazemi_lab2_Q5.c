/*
 * Kazemi_lab5_Q5.c
 *
 * Created: 3/7/2022 9:34:20 PM
 * Author: Kazemi
 */

#include <header.h>
#include <func5.h>



void main(void)
{
  seven_seg_display (888, port_C, port_D);
}


