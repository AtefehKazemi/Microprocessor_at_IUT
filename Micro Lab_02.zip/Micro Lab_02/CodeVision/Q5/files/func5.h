#ifndef __func5_INCLUDED__
#define __func5_INCLUDED__

void seven_seg_display (int data, int data_port, int enable_data);

#endif

