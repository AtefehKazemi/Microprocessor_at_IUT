#include <header.h>
#include <func5.h>



char array[]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};    

void seven_seg_display (int data, int data_port, int enable_data){
unsigned int i = 0;             
    unsigned int temp = 0;
     int SevenSeg1 =0;
     int SevenSeg2 = 0;
     int SevenSeg3 = 0;
     int SevenSeg4 = 0;
     
     switch(data_port)
       {
         case port_A:
            DDRA=0xFF; 
            break ;
         case port_B:
            DDRB=0xFF; 
            break;
         case port_C:
            DDRC=0xFF;
            break;
         case port_D:
             DDRD=0xFF;
             break;
       }
      
   
    DDRD = 0x0F;  
    
    
   
    while(data > 0){   
        if(data >= 1000){
            SevenSeg1 = data % 10;
            data = data / 10;
            SevenSeg2 = data % 10;
            data = data / 10;
            SevenSeg3 = data % 10;
            data = data / 10;
            SevenSeg4 = data % 10;
        }                                           
        else if(data >=100) {
            SevenSeg1 = data % 10;
            data = data / 10;
            SevenSeg2 = data % 10;
            data = data / 10;
            SevenSeg3 = data % 10;
            SevenSeg4 = 0;        
        }  
        else if(data >= 10){
            SevenSeg1 = data % 10;
            data = data / 10;
            SevenSeg2 = data % 10;
            SevenSeg3 = 0;
            SevenSeg4 = 0;
        }     
        else{
            SevenSeg1 = data % 10;
            SevenSeg2 = 0;
            SevenSeg3 = 0;
            SevenSeg4 = 0;
                         
        } 
        }
          while(1){
           PORTD.3 = 1;
           PORTD = array[SevenSeg1];
           //delay_ms(1);
            
           PORTD.3 = 0;
           PORTD.2 = 1;
           PORTC = array[SevenSeg2] + 0b10000000;
           //delay_ms(1);
            
            PORTD.2 = 0;
            PORTD.1 = 1;
            PORTC = array[SevenSeg3];
            //delay_ms(1);
           
            PORTD.1 = 0;
            PORTD.0 = 1;
            PORTC = array[SevenSeg4]; 
            //delay_ms(1);    
            PORTD.0 = 0;  
            }
        
                                  
 }             