#ifndef _func4_INCLUDED_
#define _func4_INCLUDED_

void portfun4(unsigned int port_in,unsigned int port_out);

#endif
