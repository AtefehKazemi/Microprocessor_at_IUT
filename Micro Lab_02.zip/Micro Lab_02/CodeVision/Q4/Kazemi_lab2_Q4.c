/*
 * Kazemi_lab2_Q4.c
 *
 * Created: 3/7/2022 9:14:35 PM
 * Author: Kazemi
 */

#include <func4.h>
#include <header.h>



void main(void)
{
char data_out;
while(1)
 {
  portfun4(1,2);
 }
}

