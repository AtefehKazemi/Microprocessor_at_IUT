#include <func6.h>
#include <header.h>

void portfun4(unsigned int port_in,unsigned int port_out)
{
char data_in;

switch(port_in)
{
case port_A:
DDRA=0x00;
data_in=PINA;
break ;
case port_B:
DDRB=0x00; 
data_in=PINB;
break;
case port_C:
DDRC=0x00; 
data_in=PINC;
break;
case port_D:
DDRD=0x00; 
data_in=PIND;
break;
}


switch( port_out)
{
case port_A:
DDRA=0xFF; 
PORTA=data_in;
break ;
case port_B:
DDRB=0xFF; 
PORTB=data_in;
break;
case port_C:
DDRC=0xFF;
PORTC=data_in;
break;
case port_D:
DDRD=0xFF;
PORTD=data_in;
break;
}
return;
}