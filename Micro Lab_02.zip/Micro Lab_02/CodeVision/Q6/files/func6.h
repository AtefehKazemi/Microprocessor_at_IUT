#ifndef __func6_INCLUDED__
#define __func6_INCLUDED__

unsigned int portfun1(unsigned int port_in);
unsigned int portfun2(unsigned int port_out,unsigned int data_in);
void func3(char count, char port, int wait);
void portfun4(unsigned int port_in,unsigned int port_out);



#endif


