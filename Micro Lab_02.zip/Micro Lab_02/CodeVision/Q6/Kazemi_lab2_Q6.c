/*
 * Kazemi_lab2_Q6.c
 *
 * Created: 3/7/2022 10:36:58 PM
 * Author: Kazemi
 */

#include <header.h>
#include <func6.h>

void main(void)
{
char data_out;

  data_out=portfun1(port_A);
  data_out=portfun2(port_B,0xf0);
  func3(5, port_B, 1000);
  //func3(5, 2, 1000);
  while(1){
  portfun4(1,2); 
  }
 

}
