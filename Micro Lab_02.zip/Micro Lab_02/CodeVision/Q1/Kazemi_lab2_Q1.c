/*
 * Kazemi_lab2_Q1.c
 *
 * Created: 3/7/2022 6:18:36 PM
 * Author: Kazemi
 */

#include <mega16.h>
#define port_A 1
#define port_B 2
#define port_A 1
#define port_B 2
#define port_C 3
#define port_D 4
/**********************************/
#include <mega16.h>
#include <delay.h>
#include <func1.h>

void main(void)
{
char data_out;
while(1)
 {
  data_out=portfun1(port_A);
 }
}