#ifndef __func1_INCLUDED__
#define __func1_INCLUDED__

unsigned int portfun1(unsigned int port_in);


#endif

