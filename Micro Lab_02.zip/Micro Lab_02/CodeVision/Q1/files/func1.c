#include <mega16.h>
#define port_A 1
#define port_B 2
#define port_C 3
#define port_D 4

unsigned int portfun1(unsigned int port_in)
{
char data_in;

switch(port_in)
{
case port_A:
DDRA=0x00; // as input
data_in=PINA;
break ;
case port_B:
DDRB=0x00; // as input
data_in=PINB;
break;
case port_C:
DDRC=0x00; // as input
data_in=PINC;
break;
case port_D:
DDRD=0x00; // as input
data_in=PIND;
break;
}

return data_in;
}
