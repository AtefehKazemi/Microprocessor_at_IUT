#include <header.h>
#include <func2.h>

unsigned int portfun2(unsigned int port_out,unsigned int data_in) {

switch( port_out)
{
case port_A:
DDRA=0xFF; // as output
PORTA=data_in;
break ;
case port_B:
DDRB=0xFF; // as output
PORTB=data_in;
break;
case port_C:
DDRC=0xFF; // as output
PORTC=data_in;
break;
case port_D:
DDRD=0xFF; // as output
PORTD=data_in;
break;
}
return 1;
}