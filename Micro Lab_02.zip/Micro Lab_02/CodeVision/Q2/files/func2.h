#ifndef _func2_INCLUDED_
#define _func2_INCLUDED_

unsigned int portfun2(unsigned int port_out,unsigned int data_in);


#endif

