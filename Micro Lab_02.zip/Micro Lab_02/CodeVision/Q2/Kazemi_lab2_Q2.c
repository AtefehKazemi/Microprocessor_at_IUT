/*
 * Kazemi_lab2_Q2.c
 *
 * Created: 3/7/2022 7:17:29 PM
 * Author: Kazemi
 */

#include <header.h>
#include <func2.h>


void main(void)
{
char data_out;
while(1) {
data_out=portfun2(port_B,0xf0);
}
}


