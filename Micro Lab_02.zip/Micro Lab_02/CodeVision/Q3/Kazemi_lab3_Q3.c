/*
 * Kazemi_lab3_Q3.c
 *
 * Created: 3/7/2022 7:41:57 PM
 * Author: Kazemi
 */

#include <header.h>
#include <func3.h>



void main(void)
{

func3(5, port_B, 1000);
//func3(5, 2, 1000);

}


