#ifndef _func3_INCLUDED_
#define _func3_INCLUDED_

void func3(char count, char port, int wait);

#endif

