#ifndef _Funcs_INCLUDED_
#define _Funcs_INCLUDED_

void Init();
void timerInit();
void Q2();
void Q4();
void Q5();
void Q7();
void calculateSpeed();
void runStepperMotor();


#endif

