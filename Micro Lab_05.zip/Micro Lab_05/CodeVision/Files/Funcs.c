#include <header.h>
void Q2(){
    TCCR0=(1<<WGM00) | (1<<COM01) | (0<<COM00) | (0<<WGM01) | (1<<CS02) | (0<<CS01) | (1<<CS00);
    TCNT0=0x00;
    OCR0=0xB2; //duty cycle = 70%....we can change it manually
    // Timer(s)/Counter(s) Interrupt(s) initialization
    TIMSK=(0<<OCIE2) | (0<<TOIE2) | (0<<TICIE1) | (0<<OCIE1A) | (0<<OCIE1B) | (0<<TOIE1) | (0<<OCIE0) | (1<<TOIE0);


}

void Q4(){

    DDRA = 0x00;

    TCCR0=(1<<WGM00) | (1<<COM01) | (0<<COM00) | (0<<WGM01) | (1<<CS02) | (0<<CS01) | (1<<CS00);
    TCNT0=0x00;
    OCR0=0x80; //duty cycle = 50%
    // Timer(s)/Counter(s) Interrupt(s) initialization
    TIMSK=(0<<OCIE2) | (0<<TOIE2) | (0<<TICIE1) | (0<<OCIE1A) | (0<<OCIE1B) | (0<<TOIE1) | (0<<OCIE0) | (1<<TOIE0);


}


void Q5(){


    DDRD = 0x03;
    ASSR=0<<AS2;
    TCCR2=(0<<PWM2) | (0<<COM21) | (0<<COM20) | (0<<CTC2) | (1<<CS22) | (1<<CS21) | (1<<CS20);
    TCNT2=0x0B; //31.36 ms
    OCR2=0x00;


    // Timer(s)/Counter(s) Interrupt(s) initialization
    TIMSK=(0<<OCIE2) | (1<<TOIE2) | (0<<TICIE1) | (0<<OCIE1A) | (0<<OCIE1B) | (0<<TOIE1) | (0<<OCIE0) | (0<<TOIE0);


}

void Q7(){
    DDRA = 0x00;
    DDRD = 0x03;
    timerInit();
}

void calculateSpeed(){
    //each step -> 31.36 ms -> 0.031 s
    //each second -> 32 steps per second
    lcd_clear();
    lcd_gotoxy(0,0);
    lcd_puts("speed:32 steps  per second");
}



void runStepperMotor(){
         CNT++;
        if (TempCNT < 0){
            PORTD.0 = 0;
            PORTD.1 = 0;
           }
        else if (LeftRight == 1){ //Right
            PORTD.0 = 0;
            PORTD.1 = 1;
           }
         else {
            PORTD.0 = 1;
            PORTD.1 = 0;
            }
     
    if (LeftRight == 1){ //Right
        if (CNT == 1) {
            PORTB.4 = 1;  //A
            PORTB.5 = 0;  //B
            PORTB.6 = 0;  //C
            PORTB.7 = 0;  //D
        }
        if (CNT == 2) {
            PORTB.4 = 0;  //A
            PORTB.5 = 1;  //B
            PORTB.6 = 0;  //C
            PORTB.7 = 0;  //D
        }
        if (CNT == 3) {
            PORTB.4 = 0;  //A
            PORTB.5 = 0;  //B
            PORTB.6 = 1;  //C
            PORTB.7 = 0;  //D
        }
        if (CNT == 4) {
            PORTB.4 = 0;  //A
            PORTB.5 = 0;  //B
            PORTB.6 = 0;  //C
            PORTB.7 = 1;  //D
        }
    }

    if (LeftRight == 0){ //Left
        if (CNT == 1) {
            PORTB.4 = 0;  //A
            PORTB.5 = 0;  //B
            PORTB.6 = 0;  //C
            PORTB.7 = 1;  //D
        }
        if (CNT == 2) {
            PORTB.4 = 0;  //A
            PORTB.5 = 0;  //B
            PORTB.6 = 1;  //C
            PORTB.7 = 0;  //D
        }
        if (CNT == 3) {
            PORTB.4 = 0;  //A
            PORTB.5 = 1;  //B
            PORTB.6 = 0;  //C
            PORTB.7 = 0;  //D
        }
        if (CNT == 4) {
            PORTB.4 = 1;  //A
            PORTB.5 = 0;  //B
            PORTB.6 = 0;  //C
            PORTB.7 = 0;  //D
        }
    }

    if (CNT == 5) CNT = 0;

    TempCNT++;
    if (TempCNT > 100){
        TempCNT = -80;
        if (LeftRight == 1){ //Right
            LeftRight = 0; //Left
        }
        else {
            LeftRight = 1; //Right
        }

        PORTB.4 = 0;  //A
        PORTB.5 = 0;  //B
        PORTB.6 = 0;  //C
        PORTB.7 = 0;  //D
    }
    if (TempCNT < 0){
        PORTB.4 = 0;  //A
        PORTB.5 = 0;  //B
        PORTB.6 = 0;  //C
        PORTB.7 = 0;  //D
    }
}

