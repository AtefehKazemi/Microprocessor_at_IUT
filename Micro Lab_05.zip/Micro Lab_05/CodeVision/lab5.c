#include <header.h>

int inputNumber = 0;
float dutyCycle = 0;
float ocrNumber = 0;
int CNT = 0;
int TempCNT = 0;
int LeftRight = 1; //Left = 0 & Right = 1


// Timer 0 overflow interrupt service routine
interrupt [TIM0_OVF] void timer0_ovf_isr(void)
{
// Place your code here
     inputNumber = PINA;

    dutyCycle = ((inputNumber * 100) / 255);
    ocrNumber = floor(2.55 * dutyCycle);

    OCR0 = ocrNumber;

}


// Timer2 overflow interrupt service routine
interrupt [TIM2_OVF] void timer2_ovf_isr(void)
{

    TCNT2=0x0B;

    runStepperMotor();
    calculateSpeed();

}

void main(void)
{
    Init();
    #asm("sei")
    lcd_init(16);

    //Q2();
    //Q4();
    //Q5();
    Q7();
}
