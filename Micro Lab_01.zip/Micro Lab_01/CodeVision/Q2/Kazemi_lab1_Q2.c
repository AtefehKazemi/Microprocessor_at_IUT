/*
 * Kazemi_lab1_Q2.c
 *
 * Created: 2/28/2022 4:58:40 PM
 * Author: Kazemi
 */

#include <io.h>
#include <delay.h>


void main(void)
{
    int counter;   
    DDRB = 0xFF; 
    PORTB = 0x80;
    counter = 0;
    while(counter != 3000){
              PORTB = PORTB>>1;     
              if(PORTB == 0x00)
                PORTB =  0x80;
              delay_ms(50);
              counter += 50;
    }   
    while(1);
    return ;
}

