/*
 * Kazemi_lab1_Q4.c
 *
 * Created: 2/28/2022 5:49:38 PM
 * Author: Kazemi
 */

#include <io.h>
#include <delay.h>
	
char array[]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};   


void func(){
    int i = 9; 
    DDRC = 0xFF;
    DDRD = 0x0F;
    PORTD = 0x00;      
     while(i !=-1){
        PORTC = array[i];    
        delay_ms(500);
        i--;
      
    }
}

void main(void)
{
   
   func();
    while(1);
    return;
}

