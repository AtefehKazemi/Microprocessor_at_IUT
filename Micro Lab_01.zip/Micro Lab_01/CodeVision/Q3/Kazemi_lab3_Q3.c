/*
 * Kazemi_lab3_Q3.c
 *
 * Created: 2/28/2022 5:17:49 PM
 * Author: Kazemi
 */

#include <io.h>
#include <delay.h>


void main(void)
{
    
    DDRA = 0x00;
    DDRB = 0xFF;
    PORTB = PINA;
    while (1)
    {
    // Please write your application code here

    }    
    return;
}